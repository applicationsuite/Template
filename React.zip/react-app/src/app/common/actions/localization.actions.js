import { createAction } from '../utility';

export const SET_LOCALIZATION = "PLATFORM/SET_LOCALIZATION";
export const setLocalization = createAction(SET_LOCALIZATION, true, "localStrings");

export const GET_LOCALIZATION = "PLATFORM/GET_LOCALIZATION";
export const getLocalization = createAction(GET_LOCALIZATION, true, "localizationLanguage");

export const SET_LOCALIZATION_LANGUAGE = "PLATFORM/SET_LOCALIZATION_LANGUAGE";
export const setLocalizationLanguage = createAction(SET_LOCALIZATION_LANGUAGE, true, "localizationLanguage");