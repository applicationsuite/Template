import { createStore, applyMiddleware } from 'redux';
import createSagaMiddleware from 'redux-saga';
import reducer from './combineReducer';
import { initialState } from './initialState';
import { initSagas } from './initSagas';

export const getStore = () => {
    const sagaMiddleware = createSagaMiddleware();
    const store = createStore(
        reducer,
        initialState,
        applyMiddleware(sagaMiddleware),
    );
    initSagas(sagaMiddleware);
    return store;
};
