import { combineReducers } from 'redux';

import * as CommonReducers from './app/common/reducers'
import * as ModuleReducers from './app/module/reducers'

export default combineReducers({
    CommonReducers,
    ModuleReducers
});
