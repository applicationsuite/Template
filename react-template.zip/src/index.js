import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import '../node_modules/office-ui-fabric-react/dist/css/fabric.min.css'
import './index.css';
import App from './app/app';
import registerServiceWorker from './registerServiceWorker';
import { getStore } from './store';
import { initializeIcons } from '@uifabric/icons';
initializeIcons();

const store = getStore();
ReactDOM.render((
        <Provider store={store}>
            <App />
        </Provider>
    ), document.getElementById('root'));
registerServiceWorker();
