import { combineReducers } from 'redux';
//
import * as CommonReducers from './app/common/reducers'
import * as ModuleReducers from './app/module/reducers'

import {sampleReducer} from './app/module/reducers'

const reducers = {...CommonReducers,...ModuleReducers};
console.log(reducers);

export default combineReducers({
    sampleReducer
});
