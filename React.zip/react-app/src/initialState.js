import { fromJS } from 'immutable'

export const initialState = { 
    state: fromJS({

     })
};