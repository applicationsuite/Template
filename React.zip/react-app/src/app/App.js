import React, { Component } from 'react';
import './app.css';
import {
  BrowserRouter as Router,
  Route,
  Switch,
  Redirect
} from 'react-router-dom';
import Header from './layout/Header/Header';
import Home from './layout/Home/Home';
import NotFound from './common/components/NotFound';
import Module from './module/Module';

class App extends Component {
  render() {
    return (
      <Router>
        <div>
          <Header />
          <Switch>
            <Route exact path="/" component={Home} />
            <Route exact path="/module" component={Module} />
            <Route exact path="/notfound" component={NotFound} />
            <Redirect to="/notfound" />
          </Switch>
        </div>
      </Router>
    );
  }
}

export default App;

App.propTypes = {

}
