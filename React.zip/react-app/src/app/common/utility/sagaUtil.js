import { call } from 'redux-saga/effects';
import {fetchData} from './fetchData';
import cache from 'memory-cache';
let mCache = new cache.Cache();

export function* InvokeUrl(url, method, data, config){
    //yield put()
    var reqHeaders =  {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Source':'UI'
    };
    if(config !== null && config !== undefined)
    {
        reqHeaders= Object.assign( reqHeaders,config);
    }
    const { response, error } = yield call(fetchData, url, {
        method: method,
        headers:reqHeaders,
        body: data,
        credentials: 'same-origin'
    });
    //yield put()
    return response ? response : error;
}

export function* InvokeCachedUrl(url, method, data){
    let cacheResponse = mCache.get(url);
    if(cacheResponse){
        return cacheResponse;
    }
    else{
        let response = yield call(InvokeUrl, url, method,data);
        mCache.put(url,response, 5000*1000);
        return response;
    }
}
