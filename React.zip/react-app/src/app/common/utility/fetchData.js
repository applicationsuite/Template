export const fetchData = (url,options) =>{
    return fetch(url,options)
            .then(response => ({response}))
            .catch(error => ({error}))

}