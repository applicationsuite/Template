import React from 'react';
import './home.css'

const Home = () => {
    return (
         <div className="home-container">
             Welcome to Order UX 
         </div>
    );
}

export default Home;