import React from 'react';
import './Home.css'

const Footer = () => {
    return (
         <div className="footer-container">
              
         </div>
    );
}

export default Home;