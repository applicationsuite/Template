import React, { Component } from 'react';
import './app.css';
import {
  BrowserRouter as Router,
  Route,
  Switch,
  Redirect
} from 'react-router-dom';
import Header from './layout/header/header';
import Home from './layout/home/home';
import NotFound from './common/components/not-found/notFound';
import Module from './module/module';

class App extends Component {
  render() {
    return (
      <Router>
        <div>
          <Header />
          <Switch>
            <Route exact path="/" component={Home} />
            <Route exact path="/module" component={Module} />
            <Route exact path="/notfound" component={NotFound} />
            <Redirect to="/notfound" />
          </Switch>
        </div>
      </Router>
    );
  }
}

export default App;

App.propTypes = {

}
