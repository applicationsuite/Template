﻿
export const REQUEST_USERS = 'app/module/REQUEST_USERS';
export const REQUEST_USERS_SUCCESS = 'app/module/REQUEST_USERS';
export const REQUEST_USERS_FAILED = 'app/module/REQUEST_USERS';

export const REQUEST_USER = 'app/module/REQUEST_USER';
export const REQUEST_USER_SUCCESS = 'app/module/REQUEST_USER';
export const REQUEST_USER_FAILED = 'app/module/REQUEST_USER';

export const REQUEST_REPOSITORY = 'app/module/REQUEST_USER';
export const REQUEST_REPOSITORY_SUCCESS = 'app/module/REQUEST_USER';
export const REQUEST_REPOSITORY_FAILED = 'app/module/REQUEST_USER';


