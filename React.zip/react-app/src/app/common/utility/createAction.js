export const createAction = (type, track, ...argNames) =>{
    return function(...args){
        let action = {type};
        action["trackActions"] = track? true: false;
        argNames.forEach((item,index)=>{
            action[argNames[index]] = args[index];
        });
        return action;
    }
};

