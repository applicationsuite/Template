﻿
export const COMMON_CONSTANTS = {
    property: 'value',  
};
