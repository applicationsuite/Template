import React from 'react';
import './home.css'

const Footer = () => {
    return (
         <div className="footer-container">
              
         </div>
    );
}

export default Home;